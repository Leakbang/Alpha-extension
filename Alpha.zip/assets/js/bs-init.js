$(document).ready(function(){
	$('[data-bss-tooltip]').tooltip();
});